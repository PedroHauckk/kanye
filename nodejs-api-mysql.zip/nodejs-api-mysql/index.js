const express = require('express');
const mysql = require('mysql');
const ejs = require('ejs');

const app = express();
const port = 3000;

// Configuração da conexão com o banco de dados
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Substitua pelo seu usuário do MySQL
  password: 'Alunos@proz', // Substitua pela sua senha do MySQL
  database: 'kanye'
});

// Conectar ao banco de dados
db.connect(err => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
  } else {
    console.log('Conexão bem-sucedida ao banco de dados');
  }
});

// Configuração do EJS como mecanismo de visualização
app.set('view engine', 'ejs');

// Rota para exibir citações do Kanye West
app.get('/', (req, res) => {
  // Consulta ao banco de dados para obter uma citação do Kanye
  db.query('SELECT quote FROM kanye_quotes ORDER BY RAND() LIMIT 1', (err, results) => {
    if (err) {
      console.error('Erro na consulta ao banco de dados:', err);
      res.status(500).send('Erro interno do servidor');
    } else {
      const quote = results[0].quote;
      res.render('index', { quote });
    }
  });
});

// Inicie o servidor na porta especificada
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
